import { Component, OnInit } from '@angular/core';  
import { User } from '../model/user';  
import { ScrollService } from '../service/scroll.service';
  
@Component({  
  selector: 'app-scroll',  
  templateUrl: './scroll.component.html',  
  styleUrls: ['./scroll.component.css']  
})  
export class ScrollComponent implements OnInit {  
  allUser: User[] = [];  
  page: number = 1;  
  constructor(private service: ScrollService) { }  
  displayedColumns: string[] = ['userid', 'username', 'emailid', 'gender','address','mobileno','pincode'];  
  ngOnInit() {  
    this.AllUserDetails();  
  }  
  
  AllUserDetails() {  
    this.service.UserDetails(this.page).subscribe((res) => {  
      this.allUser = res;  
    });  
  }  
  onScroll() {  
    this.page = this.page + 1;  
    this.AllUserDetails();  
  }  
}  