import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { UserDetail } from '../user';
import { SelectionModel } from '@angular/cdk/collections';
import { UserService } from '../service/user.service';
import { MatDialog, MatDialogConfig } from "@angular/material/dialog";
import { UserDetailComponent } from '../user-detail/user-detail.component';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {


  TotalRow!: number;

  displayedColumns: string[] = ['userid', 'username', 'emailid', 'mobileno', 'Action'];
  dataSource!: MatTableDataSource<UserDetail>;
  selection = new SelectionModel<UserDetail>(true, []);
  constructor(private service: UserService, private dialog: MatDialog, ) { }

  ngOnInit(): void {

    this.LoadData();
  }

  LoadData() {
    this.service.getUsers().subscribe(result => {
      this.dataSource = new MatTableDataSource(result);
    })
  }
  openDialog(data : any) {
    debugger;
    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.position = {
      'top': '100px',
      'left': '500px'
    };
    dialogConfig.width = '500px';
    dialogConfig.height = '500px';
    dialogConfig.data = {
      userid: data.userid
    };

    this.dialog.open(UserDetailComponent, dialogConfig);
  }
}
