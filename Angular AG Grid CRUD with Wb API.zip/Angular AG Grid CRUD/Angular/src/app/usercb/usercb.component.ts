import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { UserDetail } from '../user';
import { SelectionModel } from '@angular/cdk/collections';
import { UserService } from '../service/user.service';

@Component({
  selector: 'app-usercb',
  templateUrl: './usercb.component.html',
  styleUrls: ['./usercb.component.css']
})
export class UsercbComponent implements OnInit {

 TotalRow!: number;  
  displayedColumns: string[] = ['select', 'userid', 'username', 'emailid', 'gender', 'address', 'mobileno', 'pincode'];  
  dataSource!: MatTableDataSource<UserDetail>;  
  selection = new SelectionModel < UserDetail > (true, []);  
  constructor(private service: UserService) {}  
  ngOnInit(): void {  
      this.LoadData();  
  }  
  LoadData() {  
      this.service.getUsers().subscribe(result => {  
          this.dataSource = new MatTableDataSource(result);  
      })  
  }  
  /** Whether the number of selected elements matches the total number of rows. */  
  isAllSelected() {  
      const numSelected = this.selection.selected.length;  
      const numRows = !!this.dataSource && this.dataSource.data.length;  
      return numSelected === numRows;  
  }  
  /** Selects all rows if they are not all selected; otherwise clear selection. */  
  masterToggle() {  
      this.isAllSelected() ? this.selection.clear() : this.dataSource.data.forEach(r => this.selection.select(r));  
  }  
  /** The label for the checkbox on the passed row */  
  checkboxLabel(row: UserDetail): string {  
      if (!row) {  
          return `${this.isAllSelected() ? 'select' : 'deselect'} all`;  
      }  
      return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.userid + 1}`;  
  }  
  DeleteData() {  
      debugger;  
      const numSelected = this.selection.selected;  
      if (numSelected.length > 0) {  
          if (confirm("Are you sure to delete items ")) {  
              this.service.deleteData(numSelected).subscribe(result => {  
                  alert(result);  
                  this.LoadData();  
              })  
          }  
      } else {  
          alert("Select at least one row");  
      }  
  }

}
