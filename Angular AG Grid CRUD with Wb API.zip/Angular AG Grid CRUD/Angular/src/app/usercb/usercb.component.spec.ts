import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UsercbComponent } from './usercb.component';

describe('UsercbComponent', () => {
  let component: UsercbComponent;
  let fixture: ComponentFixture<UsercbComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UsercbComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UsercbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
