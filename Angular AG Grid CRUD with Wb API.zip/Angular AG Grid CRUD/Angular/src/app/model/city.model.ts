export class City {
    District_Code : string | undefined;  
    District_Name : string | undefined;  
}
