export class State {
   State_Code : string | undefined;  
   State_Name : string | undefined;  
}
