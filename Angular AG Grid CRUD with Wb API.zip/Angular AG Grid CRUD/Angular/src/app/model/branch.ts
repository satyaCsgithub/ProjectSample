export class Branch {
    BranchId!: number;  
    BranchName!: never; 
}
