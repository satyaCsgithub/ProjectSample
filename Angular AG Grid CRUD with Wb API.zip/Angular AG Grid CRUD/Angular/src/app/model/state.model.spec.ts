import { State } from './state.model';

describe('State', () => {
  it('should create an instance', () => {
    expect(new State()).toBeTruthy();
  });
});
