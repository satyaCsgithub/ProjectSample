export interface IUser {
    userid: number;  
    username: string;  
    emailid: string;  
    gender: string;  
    address: string;  
    mobileno: string;  
    pincode: string;
}
