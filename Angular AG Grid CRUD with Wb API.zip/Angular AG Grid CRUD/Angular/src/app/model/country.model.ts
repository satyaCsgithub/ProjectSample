export class Country {
    Country_Code :string | undefined;  
    Country_Name :string | undefined;  
}
