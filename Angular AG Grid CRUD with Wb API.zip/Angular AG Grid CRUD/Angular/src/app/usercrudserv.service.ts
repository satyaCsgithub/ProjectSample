import {Injectable} from '@angular/core';  
import {Usercrudmodel} from 'src/app/usercrudmodel';  
import {HttpClient,HttpHeaders} from '@angular/common/http';  
import {Observable} from 'rxjs';  
@Injectable({  
  providedIn: 'root'  
})  
export class UserCrudService {  
  apiUrl:string = "http://localhost:50685/Api/UserDetailGridCRUD/";

  constructor(private http : HttpClient) { 
  }

   editUser(user: Usercrudmodel){
    return this.http.put(this.apiUrl+ 'UpdateEmployeeDetails/', user );
  }

  getUsers(): Observable<Usercrudmodel[]> {  
    return this.http.get<Usercrudmodel[]>(`${this.apiUrl}GetUserDetails`);
  }  
   
  addUser(user: Usercrudmodel): Observable<string> {  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };  
    return this.http.post<string>(`${this.apiUrl}/InsertUserDetails/`, user, httpOptions);  
  }  
  updateUser(user: Usercrudmodel): Observable<string> {  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };  
    return this.http.put<string>(`${this.apiUrl}/UpdateEmployeeDetails/`, user, httpOptions);  
  }  

  deleteUser(userId: string): Observable<string> {  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };  
    return this.http.delete<string>(`${this.apiUrl}/DeleteUserDetails?id=` + userId, httpOptions);
  }  
}  