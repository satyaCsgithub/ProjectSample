import { TestBed } from '@angular/core/testing';

import { UsercrudservService } from './usercrudserv.service';

describe('UsercrudservService', () => {
  let service: UsercrudservService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UsercrudservService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
