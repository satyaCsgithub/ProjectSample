import { Injectable } from '@angular/core';  
import { HttpClient } from '@angular/common/http';  
import { Country } from '../model/country.model';  
import { State } from '../model/state.model';  
import { City } from '../model/city.model';  
  
@Injectable({  
  providedIn: 'root'  
})  
export class CommonService {  
  readonly url = 'http://localhost:50685/Api/BranchAPI/';  
  listCountry : Country[] | undefined;  
  listState: State[] | undefined;  
  listCity: City[] | undefined;  
  constructor(private http: HttpClient) { }  
  
  CountryList() {  
    this.http.get(this.url + 'CountryDetails').toPromise().then(result=>this.listCountry = result as Country[])  
  }  
  
  StateByCountry(countryID:string) {  
   return this.http.get(this.url + 'StateDetails/' + countryID).toPromise().then(result=>this.listState = result as State[])  
  }  
    
  DistrictByState(stateID:string) {  
    return this.http.get(this.url + 'CityDetails/' + stateID).toPromise().then(result=>this.listCity = result as City[])  
   }  
}  