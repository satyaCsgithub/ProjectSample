import { Usercrudmodel } from './usercrudmodel';

describe('Usercrudmodel', () => {
  it('should create an instance', () => {
    expect(new Usercrudmodel()).toBeTruthy();
  });
});
