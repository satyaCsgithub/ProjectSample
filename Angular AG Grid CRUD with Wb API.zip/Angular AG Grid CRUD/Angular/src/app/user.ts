export class UserDetail {
    userid!: number;  
    username!: string | undefined;  
    emailid!: string | undefined;  
    gender!: string | undefined;  
    address!: string | undefined;  
    mobileno!: string | undefined;  
    pincode!: string | undefined;
}
