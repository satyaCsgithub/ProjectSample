import { Component, OnInit } from '@angular/core';  
import { CommonService } from '../shared/common.service';  
@Component({  
   selector: 'app-country',  
   templateUrl: './country.component.html',  
   styleUrls: ['./country.component.css']  
})  
export class CountryComponent implements OnInit {  
   constructor(public service:CommonService) {  
}  
ngOnInit() {  
   this.service.CountryList();  
}  
BindState(countryId : string){  
   this.service.StateByCountry(countryId);  
}  
BindCity(stateId : string){  
   this.service.DistrictByState(stateId);  
   }  
}  