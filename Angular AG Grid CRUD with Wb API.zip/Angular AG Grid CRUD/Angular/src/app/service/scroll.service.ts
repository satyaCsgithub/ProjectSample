import { Injectable } from '@angular/core';  
import { HttpClient } from '@angular/common/http';    
import { User } from '../model/user';  
import { Observable } from 'rxjs';  
  
@Injectable({  
  providedIn: 'root'  
})  
export class ScrollService {
url = "http://localhost:50685/";
constructor(private http: HttpClient) { }
UserDetails(page : number): Observable<User[]> {
return this.http.get<User[]>(this.url + 'Api/ScrollAPI/ScrollAllUserDetails?pageNumber=' + page);
}
}