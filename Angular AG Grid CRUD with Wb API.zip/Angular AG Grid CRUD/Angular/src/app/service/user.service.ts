import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {
  HttpClient, HttpHeaders
} from '@angular/common/http';
import { UserDetail } from '../user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  apiUrl: string = "http://localhost:50685/Api/User/";
  constructor(private http: HttpClient) { }

  getUsers(): Observable<UserDetail[]> {
    return this.http.get<UserDetail[]>(`${this.apiUrl}GetUserDetails`);
  }
  deleteData(user: UserDetail[]): Observable < string > {  
    const httpOptions = {  
        headers: new HttpHeaders({  
            'Content-Type': 'application/json'  
        })  
    };  
    return this.http.post < string > (`${this.apiUrl}DeleteRecord/`, user, httpOptions);  
}
}
