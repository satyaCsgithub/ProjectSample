import { TestBed } from '@angular/core/testing';

import { ExceluserService } from './exceluser.service';

describe('ExceluserService', () => {
  let service: ExceluserService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ExceluserService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
