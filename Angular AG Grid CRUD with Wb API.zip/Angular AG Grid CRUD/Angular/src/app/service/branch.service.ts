import { Injectable } from '@angular/core';  
import { Observable } from 'rxjs';  
import { Branch } from '../model/branch';  
import { HttpClient, HttpHeaders } from '@angular/common/http';  
  
@Injectable({  
  providedIn: 'root'  
})  
export class BranchService {  
  
  url = "http://localhost:50685/";  
  
  constructor(private http: HttpClient) { }  
  AllBranch(): Observable<Branch[]> {  
    return this.http.get<Branch[]>(this.url + 'Api/BranchAPI/AllBranch')  
  }  
  InserCompany(companyName:string| undefined,branches:string | undefined)  
  {  
debugger;  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };    
    let companyDetails = {  
      CompanyName: companyName,  
      BranchName:branches  
         };    
    return this.http.post<string>(this.url + 'Api/BranchAPI/AddCompanyDetails/',    
    companyDetails, httpOptions);    
  }  
}