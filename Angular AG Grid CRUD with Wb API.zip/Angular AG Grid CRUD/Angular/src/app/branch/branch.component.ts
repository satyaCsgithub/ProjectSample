import { Component, OnInit } from '@angular/core';  
import { Branch } from '../model/branch';  
import { BranchService } from '../service/branch.service';  
  
@Component({  
  selector: 'app-branch',  
  templateUrl: './branch.component.html',  
  styleUrls: ['./branch.component.css']  
})  
export class BranchComponent implements OnInit {  
  lstBranch :Branch[] | undefined;  
  
  resultText=[];  
  values:string | undefined;  
  count:number=0;  
  errorMsg:string | undefined;  
  companyName:string | undefined;  
  constructor(private service: BranchService) {  
    
  }  
  ngOnInit() {  
   this.service.AllBranch().subscribe(res => {  
     this.lstBranch = res;  
   });  
 }  
  
 onChange(BranchName:never,event:any) {  
  this.errorMsg="";  
   const checked = event.target.checked;  
  
    if (checked) {  
      this.resultText.push(BranchName);  
     
       } else {  
         const index = this.resultText.indexOf(BranchName);  
         this.resultText.splice(index, 1);  
     }  
     this.values=this.resultText.toString();  
     const count=this.resultText.length;  
     this.count=count;  
  }  
  
  Save() {  
  
  const count=this.resultText.length;  
  
  if(count == 0)  
  {  
    this.errorMsg="Select at least one branch";
  }  
  else  
  {  
    this.count=count;  
  }  
    
   this.service.InserCompany(this.companyName, this.resultText.toString()).subscribe(result=>{  
alert(result);  
   });  
 }  
}