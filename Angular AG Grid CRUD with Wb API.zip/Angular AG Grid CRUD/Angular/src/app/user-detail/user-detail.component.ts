import { Component, OnInit, Inject } from '@angular/core';
import { UserService } from '../service/user.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { UserComponent } from '../user/user.component';
import { UserDetail } from '../user';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.css']
})
export class UserDetailComponent implements OnInit {

  userid: number;  
  username!: string | undefined;  
  emailid!: string | undefined;  
  gender!: string | undefined;  
  address!: string | undefined;  
  mobileno!: string | undefined;  
  pincode!: string | undefined;  
  UserDetail!: UserDetail | undefined;

  constructor(private service: UserService, private dialogRef: MatDialogRef<UserComponent>,
    @Inject(MAT_DIALOG_DATA) data: any) {

  this.userid = data.userid
}

  ngOnInit(): void {
    debugger;
    this.service.getUsers().subscribe(result => {
      this.UserDetail=result.find(a=>a.userid==this.userid);
      this.username =this.UserDetail?.username;
      this.emailid=this.UserDetail?.emailid;
      this.gender=this.UserDetail?.gender;
      this.address=this.UserDetail?.address;
      this.mobileno=this.UserDetail?.mobileno;
      this.pincode=this.UserDetail?.pincode;
    })
  }

  close() {
      this.dialogRef.close();
  }
}
