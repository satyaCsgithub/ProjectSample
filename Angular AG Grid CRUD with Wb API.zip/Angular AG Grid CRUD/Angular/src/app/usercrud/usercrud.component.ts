import { Component, OnInit} from '@angular/core';  
import {Usercrudmodel} from 'src/app/usercrudmodel';  
import { ColDef, GridApi, ColumnApi, GridOptions } from 'ag-grid-community';  
import { UserCrudService } from 'src/app/usercrudserv.service'; 
import { Router} from '@angular/router';  
import { ToastrService} from 'ngx-toastr';  
@Component({  
  selector: 'app-usercrud',  
  templateUrl: './usercrud.component.html',  
  styleUrls: ['./usercrud.component.css']  
})  
export class UsercrudComponent implements OnInit {  
  // row data and column definitions  
  public users!: Usercrudmodel[];  
  public columnDefs: ColDef[];  
  // gridApi and columnApi  
  private api!: GridApi;  
  private columnApi!: ColumnApi;  
  constructor(private userService: UserCrudService, private router: Router, private toastr: ToastrService) {  
      this.columnDefs = this.createColumnDefs();  
  }
  gridOptions: GridOptions = {
    // Enable pagination
    pagination: true,
    // Set page size to 10 rows
    paginationPageSize: 10
  }  
  ngOnInit() {  
      this.userService.getUsers().subscribe(data => {  
          this.users = data  
      })  
  }  
  // one grid initialisation, grap the APIs and auto resize the columns to fit the available space  
  onGridReady(params: { api: GridApi<any>; columnApi: ColumnApi; }): void {  
      this.api = params.api;  
      this.columnApi = params.columnApi;  
      this.api.sizeColumnsToFit();  
  }  
  // create column definitions  
  private createColumnDefs() {  
      return [{  
          headerName: 'User Name',  
          field: 'username',  
          filter: true,  
          enableSorting: true,  
          editable: true,  
          sortable: true  
      }, {  
          headerName: 'Email Id',  
          field: 'emailid',  
          filter: true,  
          editable: true,  
          sortable: true  
      }, {  
          headerName: 'Gender',  
          field: 'gender',  
          filter: true,  
          sortable: true,  
          editable: true 
          //cellRenderer: '<a href="edit-user">{{email}}</a>'  
      }, {  
          headerName: 'Address',  
          field: 'address',  
          filter: true,  
          editable: true,  
          sortable: true  
      }, {  
          headerName: 'Mobile No.',  
          field: 'mobileno',  
          filter: true,  
          editable: true  
      }, {  
          headerName: 'Pincode',  
          field: 'pincode',  
          filter: true,  
          editable: true  
      }]  
  }  
  status: any;  
  //Update user  
  editUser() {  
      debugger;  
      const d = this.api.getEditingCells();  
      if (this.api.getSelectedRows().length == 0) {  
          this.toastr.error("error", "Please select a User for update");  
          return;  
      }  
      var row = this.api.getSelectedRows();  
      this.userService.updateUser(row[0]).subscribe(data => {  
          this.toastr.success("success", data);  
          this.ngOnInit();  
      });  
  }  
  //Delete user  
  deleteUser() {  
      debugger;  
      var selectedRows = this.api.getSelectedRows();  
      if (selectedRows.length == 0) {  
          this.toastr.error("error", "Please select a User for deletion");  
          return;  
      }  
      this.userService.deleteUser(selectedRows[0].userid).subscribe(data => {  
          this.toastr.success("success", data);  
          this.ngOnInit();  
          //this.api.refreshHeader();  
      });  
  }  
  Add() {  
      this.router.navigate(['addUser']);  
  }  
}  