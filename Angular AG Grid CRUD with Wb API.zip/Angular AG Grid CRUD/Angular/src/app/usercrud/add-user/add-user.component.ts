import { Component, OnInit } from '@angular/core';  
import { UserCrudService } from 'src/app/usercrudserv.service';  
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';  
import { Router } from '@angular/router';  
import { ToastrService } from 'ngx-toastr';  
  
@Component({  
  selector: 'app-add-user',  
  templateUrl: './add-user.component.html',  
  styleUrls: ['./add-user.component.css']  
})  
export class AddUserComponent implements OnInit {  
  submitted: boolean= false;  
  userForm: any;  
    
  constructor(private formBuilder: FormBuilder,private toastr: ToastrService,private userService: UserCrudService,private router:Router) { }  
  
  ngOnInit(): void {  
    this.userForm = this.formBuilder.group({  
      "username": ["", Validators.required],  
      "emailid": ["", Validators.required],  
      "gender": ["", Validators.required],  
      "address": ["", Validators.required],  
      "mobileno": ["", Validators.required],  
      "pincode": ["", Validators.required]  
    });  
  }  
  onSubmit() {  
    this.submitted = true;  
    if (this.userForm.invalid) {  
      return;  
    }  
    this.userService.addUser(this.userForm.value)  
      .subscribe( data => {  
        this.toastr.success("success", data.toString());  
        this.router.navigate(['users']);  
      });  
  }  
  Cancel()  
  {  
    this.router.navigate(['users']);  
  }  
}  