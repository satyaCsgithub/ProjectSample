import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UsercrudComponent } from './usercrud/usercrud.component';
import { AddUserComponent } from './usercrud/add-user/add-user.component';


const routes: Routes = [
  {path:'users',  component:UsercrudComponent},
  {path:'', component:UsercrudComponent},
  {path:'addUser', component:AddUserComponent}
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }