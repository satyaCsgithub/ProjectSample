import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { MatInputModule } from '@angular/material/input';
import {  MatDialogModule} from '@angular/material/dialog'
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatToolbarModule} from '@angular/material/toolbar';
import {HttpClientModule, HttpClient } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { UserDetailComponent } from './user-detail/user-detail.component';
import { UsercbComponent } from './usercb/usercb.component';
import { BranchComponent } from './branch/branch.component';
//import { FormsModule } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ExcelimportComponent } from './excelimport/excelimport.component';    
import { AngularmaterialModule } from './material/angularmaterial/angularmaterial.module';  
import { EmployeeService } from './employee.service';
import { EmployeeComponent } from './employee/employee.component';
import { ScrollComponent } from './scroll/scroll.component';  
import {InfiniteScrollModule} from 'ngx-infinite-scroll';
import { CountryComponent } from './country/country.component';  
import { CommonService } from './shared/common.service';
import { UsercrudComponent } from './usercrud/usercrud.component';
import { AddUserComponent } from './usercrud/add-user/add-user.component';
import { UserCrudService } from 'src/app/usercrudserv.service';
import { AgGridModule } from 'ag-grid-angular';
import { ToastrModule } from 'ngx-toastr';

@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    UserDetailComponent,
    UsercbComponent,
    BranchComponent,
    ExcelimportComponent,
    AppComponent,  
    EmployeeComponent, ScrollComponent, CountryComponent, UsercrudComponent, AddUserComponent  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatCheckboxModule,
    MatDialogModule,
    MatToolbarModule,
    MatInputModule,
    MatSelectModule,
    MatTableModule,
    HttpClientModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserModule,  
    HttpClientModule,  
    BrowserAnimationsModule,  
    AngularmaterialModule,  
    AppRoutingModule,
    InfiniteScrollModule,
    ToastrModule.forRoot(),
    AgGridModule
  ],
  providers: [UserCrudService],
  bootstrap: [AppComponent]
})
export class AppModule { }
